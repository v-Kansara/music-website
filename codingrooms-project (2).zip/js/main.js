const audio = new Audio();
audio.src = "audio/sitar.mp3";

// const playing = audio.isPlaying();
// if playing === "true"

const audio2 = new Audio();
audio2.src = "audio/violin.mp3";

const audio3 = new Audio();
audio3.src = "audio/tabla.mp3";

const audio4 = new Audio();
audio4.src = "audio/mrudangam.mp3";

const audio5 = new Audio();
audio5.src = "audio/flute.mp3";

const audio6 = new Audio();
audio6.src = "audio/conch.mp3";

const audio7 = new Audio();
audio7.src = "audio/manjira.mp3";

const audio8 = new Audio();
audio8.src = "audio/bells.mp3";